<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="css/index.css?v=<?php echo time(); ?>">
  <title>Coursonada | Free IT Courses</title>

</head>

<body onload="layOutLogging()">
  <header id="header"></header>


  <nav>
    <div id="nav-container">
      <h4>Coursonada</h4>

      <div id="authentication-container">
        <a href="#login-form" id="login">Login</a>
        <a href="#registration-form"><button class="signup">Join for Free</button></a>
      </div>
    </div>
  </nav>

  <main>
  <section>
    <div class="intro-section">
      <div class="intro-left">
        <h1>Learn without Limits</h1>
        <pre>
Start, switch, or advance your IT career
with free courses from world-class
universities and professionals.
        </pre>
        <a href="#registration-form"><button class="signup-button" class="signup">Join for Free</button></a>
      </div>

      <div class="intro-right">
        <img src="img/logo.png" alt="logo">
      </div>
    </div>
  </section>


  <section id="collaborators-section">
    <h2>We collaborate with 69+ leading universities and companies</h2>

    <div id="collaborators-logo">
      <a>
        <img src="img/freecodecamp-removebg-preview.png" alt="collaborator logo">
      </a>

      <a>
        <img src="img/goog.png" alt="collaborator logo">
      </a>

      <a>
        <img src="img/yt-removebg-preview.png" alt="collaborator logo">
      </a>

      <a>
        <img src="img/w3schools.png" alt="collaborator logo">
      </a>

      <a>
        <img src="img/GitHub-logo.png" alt="collaborator logo">
      </a>

      <a>
        <img src="img/ChatGPT-Logo.png" alt="collaborator logo">
      </a>
    </div>
  </section>


  <section class="explore-section">
    <h2>Explore Coursonada</h2>

    <div class="course-container">
      <a>
      <div class="course-box">
        <img src="img/C_Programming_Course.png" alt="c logo">
        <div>
        <div class="course">C Programming</div>
        </div>
        </div>
      </a>

      <a>
      <div class="course-box">
        <img src="img/c++_programming_course.png" alt="c++ logo">
        <div>
      <div class="course">C++ Programming</div>
      </div>
      </div>
      </a>

      <a>
      <div class="course-box">
        <img src="img/java_programming_course.png" alt="java logo">
      <div>
      <div class="course">Java Programming</div>
      </div>
      </div>
      </a>

      <a>
      <div class="course-box">
        <img src="img/python_programming_course.png" alt="python logo">
      <div>
      <div class="course">Python Programming</div>
      </div>
      </div>
      </a>

      <a>
      <div class="course-box">
        <img src="img/html_programming_course.png" alt="html logo">
      <div>
      <div class="course">HTML Fundamentals</div>
      </div>
      </div>
      </a>

      <a>
      <div class="course-box">
        <img src="img/css_programming_course.png" alt="css logo">
      <div>
      <div class="course">CSS Basics</div>
      </div>
      </div>
      </a>

      <a>
      <div class="course-box">
        <img src="img/javascript_programming_course.png" alt="js logo">
      <div>
      <div class="course">JavaScript Programming</div>
      </div>
      </div>
      </a>

      <a>
      <div class="course-box">
        <img src="img/php_programming_course.png" alt="php logo">
        <div>
      <div class="course">PHP Server-side Programming</div>
      </div>
      </div>
      </a>

      <a>
      <div class="course-box">
        <img src="img/sql_programming_course.png" alt="sql logo">
      <div>
      <div class="course">SQL Database Management</div>
      </div>
      </div>
      </a>
    </div>
  </section>


  <section id="learners-report">
    <div id="report-section">
      <div class="intro right">
        <img src="img/outcomes.png" alt="outcomes_img">
      </div>

      <div class="intro-left">
        <h2>Learner outcomes on Coursonada</h2>
        <pre>
Coursonada learners gain career benefits,
including new skills, increased pay, and new job
opportunities.
        </pre>
      </div>
    </div>
  </section>


  <section id="outro-section">
    <div class="outro-content">
      <div class="outro-right">
        <img src="img/Image-Next-Step.png" alt="nxtStep img">
      </div>

      <div class="outro-left">
        <h2>Take the next step toward your personal and professional goals with Coursonada</h2>
        <pre>
Join now to receive personalized recommendations from the
full Coursonada catalog.
        </pre>
        <a href="#registration-form"><button class="signup-button" class="signup">Join for Free</button></a>
      </div>
    </div>
  </section>
  </main>

  <footer>
    <div class="footer-container">
      <div class="footer-left">
        <span>&#169; 2024 Coursonada Inc. All rights reserved</span>
      </div>

      <div class="footer-right">
        <ul class="social-media">
          <li><a href=""><img src="img/fb.png" alt="fb logo"></a></li>
          <li><a href=""><img src="img/linkedin.png" alt="linkedin logo"></a></li>
          <li><a href=""><img src="img/twitter.png" alt="twitter logo"></a></li>
          <li><a href=""><img src="img/youtube.png" alt="yt logo"></a></li>
          <li><a href=""><img src="img/insta.png" alt="ig logo"></a></li>
        </ul>
      </div>
    </div>
  </footer>
  

  <div id="overlay">
    <div id="form-container">
      <a href=""><button id="closeButton">x</button></a>

      <div id="registration-form">
        <h2>Sign Up</h2>

        <form action="formHandlers/register_Handler.php" method="post">
          <div id="name_section">
            <label for="full_name"><b>Full Name</b></label>
            <input required type="text" id="full_name" name="full_name" placeholder="Enter your full name">

            <label for="email"><b>Email</b></label>
            <input required type="email" id="email" name="email" placeholder="name@email.com">

            <label for="pwd_regi"><b>Password</b></label>
            <div class="pwd-container">
            <input required type="password" id="pwd_regi" name="pwd" placeholder="Create password">
            <img src="img/hide.png" alt="hide logo" id="toggle-pwd1" onclick="togglePasswordRegistration()">
            </div>
          </div>

          <button type="submit" value="submit" id="register_button"><b>Register</b></button>
        </form>
        <div id="already_hve_Acc">
          <p>Already have an account? <a href="#login-form" onclick="toggleForms('login')">Sign in</a></p>
        </div>
      </div>


      <div id="login-form" style="display:none">
        <h2>Welcome Back</h2>
        <form action="formHandlers/login_Handler.php" method="post">
          <div id="name_section">
          <label for="email_login"><b>Email</b></label>
          <input required type="email" id="email_login" name="email" placeholder="name@email.com">

          <label for="pwd_login"><b>Password</b></label>
            <div class="pwd-container">
            <input required type="password" id="pwd_login" name="pwd" placeholder="Create password">
            <img src="img/hide.png" alt="hide logo" id="toggle-pwd2" onclick="togglePasswordLogin()">
            </div>
          </div>
          <button type="submit" value="submit" id="login_button"><b>Log in</b></button>
        </form>
        <div id="already_hve_Acc">
          <p>New to Coursonada? <a href="#registration-form" onclick="toggleForms('registration')">Sign up</a></p>
        </div>
      </div>
    </div>
  </div>

  <script src="JS/index.js"></script>
</body>

</html>  