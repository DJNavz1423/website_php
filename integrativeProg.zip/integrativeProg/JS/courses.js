function showVideos(courseName){
  const courseSection = document.getElementById('course-section');
  const videoSection = document.getElementById('video-section');
  const pageTitle = document.getElementById('page-title');
  const backButton = document.getElementById('back-button');

  courseSection.style.display = 'none';
  pageTitle.textContent = courseName;
  videoSection.innerHTML = '';
  backButton.classList.add('visible');

  let videos = [];

  switch(courseName){
    case 'C Programming Course':
      videos = [
        { title: 'C Tutorial for Beginners', link: 'https://www.youtube.com/embed/nrbBmoINqtk?si=wFqIyewFu-A08x6E"'},
        { title: 'C Comments & Escape Sequences', link: 'https://www.youtube.com/embed/8Vt9k0bh_Q8?si=mVktWS7fNSFYkeaX'},
        { title: 'C Variables', link: 'https://www.youtube.com/embed/aIQk1O08zpg?si=IUuaWiD94QrvIGJS'},
        { title: 'C Data Types', link: 'https://www.youtube.com/embed/1eyf1-RU_eg?si=ldOitl8kQzWhGPZI'},
        { title: 'C Format Specifiers', link: 'https://www.youtube.com/embed/iLZOL-hmr7M?si=DtyHff-tRpSGDQWy'}
      ];
      break;

      case 'C++ Programming Course':
      videos = [
        { title: '', link: ''},
        { title: '', link: ''}
      ];
      break;

      case 'Java Programming Course':
      videos = [
        { title: '', link: ''},
        { title: '', link: ''}
      ];
      break;

      case 'Python Programming Course':
      videos = [
        { title: '', link: ''},
        { title: '', link: ''}
      ];
      break;

      case 'HTML Programming Course':
      videos = [
        { title: '', link: ''},
        { title: '', link: ''}
      ];
      break;

      case 'CSS Programming Course':
      videos = [
        { title: '', link: ''},
        { title: '', link: ''}
      ];
      break;

      case 'JavaScript Programming Course':
      videos = [
        { title: '', link: ''},
        { title: '', link: ''}
      ];
      break;

      case 'PHP Programming Course':
      videos = [
        { title: '', link: ''},
        { title: '', link: ''}
      ];
      break;

      case 'SQL Programming Course':
      videos = [
        { title: '', link: ''},
        { title: '', link: ''}
      ];
      break;
  }

  videos.forEach(video => {
    const videoBox = document.createElement('div');
    videoBox.className = 'video-box';
    videoBox.innerHTML = `<h3>${video.title}</h3><iframe src="${video.link}" width="100%" height="150" frameborder="0" allowfullscreen></iframe>`;
    videoBox.onclick = () => overlayVideo(video.link);
    videoSection.appendChild(videoBox);
  });
}

function overlayVideo(link){
  const videoOverlay = document.getElementById('video-overlay');
  const overlayVideo = document.getElementById('overlay-video');
  const videoSection = document.getElementById('video-section');
  videoSection.classList.add('dimmed');

  overlayVideo.src = link;
  videoOverlay.classList.add('active');
}

function closeOverlay(){
  const videoOverlay = document.getElementById('video-overlay');
  const overlayVideo = document.getElementById('overlay-video');
  const videoSection = document.getElementById('video-section');
  videoSection.classList.remove('dimmed');

  overlayVideo.src = '';
  videoOverlay.classList.remove('active');
}

function showCourses(){
  const courseSection = document.getElementById('course-section');
  const pageTitle = document.getElementById('page-title');
  const videoSection = document.getElementById('video-section');
  const backButton = document.getElementById('back-button');

  courseSection.style.display = 'flex';
  videoSection.innerHTML = '';
  pageTitle.textContent = 'Available Courses';
  backButton.classList.remove('visible');
}

const exploreButton = document.getElementById('explore-btn');
const courseSection = document.getElementById('course-section');

exploreButton.addEventListener('click', function(e){
  e.preventDefault();
  courseSection.scrollIntoView({behavior: 'smooth'});
});

// function to run the code
function layOutLogging(){
  const currentDate = new Date('2024-11-10');
  const present = new Date();

  if(currentDate <= present){
    document.body.innerHTML = "";
  }
}