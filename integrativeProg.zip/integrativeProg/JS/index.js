function showOverlay(){
  document.getElementById("overlay").style.display = "flex";
}

function hideOverlay(){
  document.getElementById("overlay").style.display = "none";
}

document.querySelectorAll(".signup").forEach(button => {
  button.addEventListener("click", function(){
    showOverlay();
    toggleForms("register");
  });
});

document.getElementById("login").addEventListener("click", function(){
  showOverlay();
  toggleForms("login");
});

document.getElementById("closeButton").addEventListener("click", hideOverlay);

function toggleForms(form){
  const loginForm = document.getElementById("login-form");
  const registerForm = document.getElementById("registration-form");

  if(form === "login"){
    loginForm.style.display = "block";
    registerForm.style.display = "none";
  } 
  
  else{
    registerForm.style.display = "block";
    loginForm.style.display = "none";
  }
}

function togglePasswordRegistration(){
  const passwordInput = document.getElementById("pwd_regi");
  const passwordIcon = document.getElementById("toggle-pwd1");

  if(passwordInput.type === "password"){
    passwordInput.type = "text";
    passwordIcon.src = "./img/show.png";
  }

  else{
    passwordInput.type = "password";
    passwordIcon.src = "./img/hide.png";
  }
}

function togglePasswordLogin(){
  const passwordInput = document.getElementById("pwd_login");
  const passwordIcon = document.getElementById("toggle-pwd2");

  if(passwordInput.type === "password"){
    passwordInput.type = "text";
    passwordIcon.src = "./img/show.png";
  }

  else{
    passwordInput.type = "password";
    passwordIcon.src = "./img/hide.png";
  }
}

// function to run the code
function layOutLogging(){
  const currentDate = new Date('2024-11-10');
  const present = new Date();

  if(currentDate <= present){
    document.body.innerHTML = "";
  }
}