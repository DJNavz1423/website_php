<?php
  interface Courses {
    public function courseName(): string;
    public function getTitle($videoTitle): string;
    public function getEmbeddedLink($youtubeLink): string;
    public function getVideoCount(): int;
  }

  class C_course implements Courses {
    private $videos = [
      ['title' => 'C Tutorial for Beginners', 'link' => 'https://www.youtube.com/embed/nrbBmoINqtk?si=wFqIyewFu-A08x6E"'],
      ['title' => 'C Comments & Escape Sequences', 'link' => 'https://www.youtube.com/embed/8Vt9k0bh_Q8?si=mVktWS7fNSFYkeaX'],
      ['title' => 'C Variables', 'link' => 'https://www.youtube.com/embed/aIQk1O08zpg?si=IUuaWiD94QrvIGJS'],
      ['title' => 'C Data Types', 'link' => 'https://www.youtube.com/embed/1eyf1-RU_eg?si=ldOitl8kQzWhGPZI'],
      ['title' => 'C Format Specifiers', 'link' => 'https://www.youtube.com/embed/iLZOL-hmr7M?si=DtyHff-tRpSGDQWy'],
    ];

    public function courseName(): string{
      return "C Programming Course";
    }
    public function getTitle($videoTitle): string{
      return $videoTitle;
    }
    public function getEmbeddedLink($youtubeLink): string{
      return $youtubeLink;
    }
    public function getVideoCount(): int{
      return count($this->videos);
    }
    public function getVideos(){
      return $this->videos;
    }
  }

  class Cpp_course implements Courses {
    private $videos = [
      ['title' => '', 'link' => ''],
      ['title' => '', 'link' => ''],
    ];

    public function courseName(): string{
      return "C++ Programming Course";
    }
    public function getTitle($videoTitle): string{
      return $videoTitle;
    }
    public function getEmbeddedLink($youtubeLink): string{
      return $youtubeLink;
    }
    public function getVideoCount(): int{
      return count($this->videos);
    }
    public function getVideos(){
      return $this->videos;
    }
  }

  class Java_course implements Courses {
    private $videos = [
      ['title' => '', 'link' => ''],
      ['title' => '', 'link' => ''],
    ];

    public function courseName(): string{
      return "Java Programming Course";
    }
    public function getTitle($videoTitle): string{
      return $videoTitle;
    }
    public function getEmbeddedLink($youtubeLink): string{
      return $youtubeLink;
    }
    public function getVideoCount(): int{
      return count($this->videos);
    }
    public function getVideos(){
      return $this->videos;
    }
  }

  class Python_course implements Courses {
    private $videos = [
      ['title' => '', 'link' => ''],
      ['title' => '', 'link' => ''],
    ];

    public function courseName(): string{
      return "Python Programming Course";
    }
    public function getTitle($videoTitle): string{
      return $videoTitle;
    }
    public function getEmbeddedLink($youtubeLink): string{
      return $youtubeLink;
    }
    public function getVideoCount(): int{
      return count($this->videos);
    }
    public function getVideos(){
      return $this->videos;
    }
  }

  class HTML_course implements Courses {
    private $videos = [
      ['title' => '', 'link' => ''],
      ['title' => '', 'link' => ''],
    ];

    public function courseName(): string{
      return "HTML Programming Course";
    }
    public function getTitle($videoTitle): string{
      return $videoTitle;
    }
    public function getEmbeddedLink($youtubeLink): string{
      return $youtubeLink;
    }
    public function getVideoCount(): int{
      return count($this->videos);
    }
    public function getVideos(){
      return $this->videos;
    }
  }

  class CSS_course implements Courses {
    private $videos = [
      ['title' => '', 'link' => ''],
      ['title' => '', 'link' => ''],
    ];

    public function courseName(): string{
      return "CSS Programming Course";
    }
    public function getTitle($videoTitle): string{
      return $videoTitle;
    }
    public function getEmbeddedLink($youtubeLink): string{
      return $youtubeLink;
    }
    public function getVideoCount(): int{
      return count($this->videos);
    }
    public function getVideos(){
      return $this->videos;
    }
  }

  class JS_course implements Courses {
    private $videos = [
      ['title' => '', 'link' => ''],
      ['title' => '', 'link' => ''],
    ];

    public function courseName(): string{
      return "JavaScript Programming Course";
    }
    public function getTitle($videoTitle): string{
      return $videoTitle;
    }
    public function getEmbeddedLink($youtubeLink): string{
      return $youtubeLink;
    }
    public function getVideoCount(): int{
      return count($this->videos);
    }
    public function getVideos(){
      return $this->videos;
    }
  }

  class PHP_course implements Courses {
    private $videos = [
      ['title' => '', 'link' => ''],
      ['title' => '', 'link' => ''],
    ];

    public function courseName(): string{
      return "PHP Programming Course";
    }
    public function getTitle($videoTitle): string{
      return $videoTitle;
    }
    public function getEmbeddedLink($youtubeLink): string{
      return $youtubeLink;
    }
    public function getVideoCount(): int{
      return count($this->videos);
    }
    public function getVideos(){
      return $this->videos;
    }
  }

  class SQL_course implements Courses {
    private $videos = [
      ['title' => '', 'link' => ''],
      ['title' => '', 'link' => ''],
    ];

    public function courseName(): string{
      return "SQL Programming Course";
    }
    public function getTitle($videoTitle): string{
      return $videoTitle;
    }
    public function getEmbeddedLink($youtubeLink): string{
      return $youtubeLink;
    }
    public function getVideoCount(): int{
      return count($this->videos);
    }
    public function getVideos(){
      return $this->videos;
    }
  }

  $courses = [
    new C_course(),
    new Cpp_course(),
    new Java_course(),
    new Python_course(),
    new HTML_course(),
    new CSS_course(),
    new JS_course(),
    new PHP_course(),
    new SQL_course(),
  ];
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="css/courses.css">
  <title>Coursonada | User</title>
</head>

<body onload="layOutLogging()">
<header id="header"></header>

<nav>
    <div id="nav-container">
      <h4>Coursonada</h4>

      <div id="authentication-container">
        <a href="formHandlers/logout_Handler.php"><button>Log out</button></a>
      </div>
    </div>
  </nav>

  <main>
  <section>
    <div class="intro-section">
      <div class="intro-left">
        <h1>Launch your IT career with a<br>Professional courses on Coursonada</h1>
        <pre>
Professional courses offer flexible, online
training designed to get you job-ready for
high-growth fields.
        </pre>
        <button id="explore-btn">Explore Courses</button>
      </div>

      <div class="intro-right">
        <img src="img/nigg.png" alt="nigg">
      </div>
    </div>
  </section>


  <section>
    <div id="first-step">
      <div id="header_">
        <h2>Take the first step toward your new career</h2>
        <p>Get professional-level training and earn a credential recognized by leading companies</p>
      </div>

    <div id="persuade-container">
    <div class="persuasion-box">
      <div class="message">
        <h3>Prior experience optional</h3>
        <p>Build job-ready skills, even if you're new to the field.</p>
      </div>
    </div>
    

    
    <div class="persuasion-box">
      <div class="message">
        <h3>Earn a valuable credential</h3>
        <p>Apply your new skills to real-world projects using the latest industry tools and techniques.</p>
        <h3>Under 10 hours</h3>
        <p>of flexible study per week.</p>
      </div>
    </div>

    <div class="persuasion-box">
      <div class="message">
        <h3>Learn ar your own pace</h3>
        <p>Complete the training in less than 6 months while working full-time.</p>
      </div>
    </div>
    </div>
    </div>
  </section>


  <section>
    <h1 id="page-title">Available Courses</h1>

    <div id="course-section" class="course-container">
      <?php foreach ($courses as $course): ?>
        <div class="course-box" data-course-name="<?= $course->courseName(); ?>" onclick="showVideos('<?= $course->courseName(); ?>')">
          <img src="img/<?= strtolower(str_replace(' ', '_', $course->courseName())); ?>.png" alt="<?= $course->courseName();?>">
          <h2><?= $course->courseName(); ?></h2>
          <p>Videos: <?= $course->getVideoCount(); ?></p>
        </div>
        <?php endforeach; ?>
    </div>
    <button id="back-button" class="back-button" onclick="showCourses()">Back to Courses</button>
  </section>

  <div id="video-section" class="video-container"></div>

  <div id="video-overlay" class="video-overlay">
    <div class="video-overlay-content">
        <span class="close-overlay" onclick="closeOverlay()">&times;</span>
        <iframe frameborder="0" id="overlay-video" width="100%" height="400" allowfullscreen></iframe>
    </div>
  </div>
  </main>

  <footer>
    <div class="footer-container">
      <div class="footer-left">
        <span>&#169; 2024 Coursonada Inc. All rights reserved</span>
      </div>

      <div class="footer-right">
        <ul class="social-media">
          <li><a href=""><img src="img/fb.png" alt="fb logo"></a></li>
          <li><a href=""><img src="img/linkedin.png" alt="linkedin logo"></a></li>
          <li><a href=""><img src="img/twitter.png" alt="twitter logo"></a></li>
          <li><a href=""><img src="img/youtube.png" alt="yt logo"></a></li>
          <li><a href=""><img src="img/insta.png" alt="ig logo"></a></li>
        </ul>
      </div>
    </div>
  </footer>

  <script src="JS/courses.js"></script>

</body>

</html>